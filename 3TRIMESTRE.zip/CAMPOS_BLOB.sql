-- MANEJO DE CAMPO BLOB

--DESCARGAMOS DOS IMÁGENES DE LA LIGA ENDESA



-- EN LA BADAT LIGA

MariaDB [liga]> alter table jugador add foto BLOB after salario;
Query OK, 0 rows affected (0.062 sec)
Records: 0  Duplicates: 0  Warnings: 0

MariaDB [liga]> select * from jugador;
+----+-------------+--------------+--------+---------+------------+---------+------+--------+
| id | nombre      | apellido     | altura | puesto  | fecha_alta | salario | foto | equipo |
+----+-------------+--------------+--------+---------+------------+---------+------+--------+
|  1 | Juan Carlos | Navarro      |    191 | Escolta | 2010-01-10 |  130000 | NULL |      1 |
|  2 | Felipe      | Reyes        |    204 | Pivot   | 2009-02-20 |  120000 | NULL |      2 |
|  3 | Víctor      | Claver       |    209 | Alero   | 2009-03-08 |   90000 | NULL |      3 |
|  4 | Rafa        | Martínez     |    191 | Escolta | 2010-11-11 |   51000 | NULL |      3 |
|  5 | Fernando    | San Emeterio |    199 | Alero   | 2008-09-22 |  130000 | NULL |      4 |
|  6 | Mirza       | Teletovic    |    206 | Pivot   | 2010-05-13 |   60000 | NULL |      4 |
|  7 | Sergio      | Llull        |    190 | Escolta | 2011-10-29 |   70000 | NULL |      2 |
|  8 | Víctor      | Sada         |    192 | Base    | 2012-01-01 |  100000 | NULL |      1 |
|  9 | Carlos      | Suárez       |    203 | Alero   | 2010-02-19 |   80000 | NULL |      2 |
| 10 | Xavi        | Rey          |    209 | Pivot   | 2011-10-12 |   95000 | NULL |      5 |
| 11 | Carlos      | Cabezas      |    186 | Base    | 2008-01-21 |  105000 | NULL |      6 |
| 12 | Pablo       | Aguilar      |    203 | Alero   | 2012-06-14 |   47000 | NULL |      6 |
| 13 | Rafa        | Hettsheimer  |    209 | Pivot   | 2011-04-15 |   53000 | NULL |      6 |
| 14 | Sitapha     | Savané       |    201 | Pivot   | 2011-07-27 |   60000 | NULL |      5 |
+----+-------------+--------------+--------+---------+------------+---------+------+--------+
14 rows in set (0.001 sec

-- COMANDO PARA CARGAR IMAGEN

update jugador set foto = LOAD_FILE('/Escritorio/BADAT/3 TRIMESTRE/Randolph_Anthony.png') where id = 1;
Query OK, 0 rows affected (0.000 sec)
Rows matched: 1  Changed: 0  Warnings: 0

-- SE PUEDE VER QUE SIGUE A NULL. 

MariaDB [liga]> select * from jugador;
+----+-------------+--------------+--------+---------+------------+---------+------+--------+
| id | nombre      | apellido     | altura | puesto  | fecha_alta | salario | foto | equipo |
+----+-------------+--------------+--------+---------+------------+---------+------+--------+
|  1 | Juan Carlos | Navarro      |    191 | Escolta | 2010-01-10 |  130000 | NULL |      1 |
|  2 | Felipe      | Reyes        |    204 | Pivot   | 2009-02-20 |  120000 | NULL |      2 |
|  3 | Víctor      | Claver       |    209 | Alero   | 2009-03-08 |   90000 | NULL |      3 |
|  4 | Rafa        | Martínez     |    191 | Escolta | 2010-11-11 |   51000 | NULL |      3 |
|  5 | Fernando    | San Emeterio |    199 | Alero   | 2008-09-22 |  130000 | NULL |      4 |
|  6 | Mirza       | Teletovic    |    206 | Pivot   | 2010-05-13 |   60000 | NULL |      4 |
|  7 | Sergio      | Llull        |    190 | Escolta | 2011-10-29 |   70000 | NULL |      2 |
|  8 | Víctor      | Sada         |    192 | Base    | 2012-01-01 |  100000 | NULL |      1 |
|  9 | Carlos      | Suárez       |    203 | Alero   | 2010-02-19 |   80000 | NULL |      2 |
| 10 | Xavi        | Rey          |    209 | Pivot   | 2011-10-12 |   95000 | NULL |      5 |
| 11 | Carlos      | Cabezas      |    186 | Base    | 2008-01-21 |  105000 | NULL |      6 |
| 12 | Pablo       | Aguilar      |    203 | Alero   | 2012-06-14 |   47000 | NULL |      6 |
| 13 | Rafa        | Hettsheimer  |    209 | Pivot   | 2011-04-15 |   53000 | NULL |      6 |
| 14 | Sitapha     | Savané       |    201 | Pivot   | 2011-07-27 |   60000 | NULL |      5 |
+----+-------------+--------------+--------+---------+------------+---------+------+--------+
14 rows in set (0.000 sec)

-- CREAMOS UNA CARPETA EN TMP CON LAS IMÁGENES, POR TEMA DE PERMISOS Y YA FUNCIONA LA RUTA
-- PREFERIBLEMENTE RECORTADAS

MariaDB [liga]> update jugador set foto = LOAD_FILE('/tmp/Afotos/Randolph_Anthony.jpg') where id = 1;
Query OK, 0 rows affected (0.000 sec)
Rows matched: 1  Changed: 0  Warnings: 0


-- SE VA A ALTERAR LA TABLA PARA QUE QUEPAN IMÁGENES DE MAYOR TAMAÑO, CON EL TIPO DE DATO MEDIUMBLOB

MariaDB [liga]> alter table jugador modify foto mediumblob;
Query OK, 14 rows affected (0.105 sec)             
Records: 14  Duplicates: 0  Warnings: 0

MariaDB [liga]> 

-- INSTALAR REDIMENSIONADOR DE ARCHIVOS

sudo apt install nemo-image-converter

-- SE REDIMENSIONAN LAS FOTOS A LA MITAD

-- SE INSERTAN LAS FOTOS REDIMENSIONADAS

MariaDB [liga]> update jugador set foto = load_file('/tmp/fotos/Claver_Victor.png') where id = 3;
Query OK, 1 row affected (0.048 sec)
Rows matched: 1  Changed: 1  Warnings: 0

MariaDB [liga]> update jugador set foto = load_file('/tmp/fotos/Pablo_Laso.jpg') where id = 1;
Query OK, 1 row affected (0.048 sec)
Rows matched: 1  Changed: 1  Warnings: 0

MariaDB [liga]> update jugador set foto = load_file('/tmp/fotos/Randolph_Anthony.jpg') where id = 2;
Query OK, 1 row affected (0.039 sec)
Rows matched: 1  Changed: 1  Warnings: 0


-- PROCESO DE EXPORTAR LA FOTO A UN ARCHIVO

MariaDB [liga]> select foto from jugador where id = 1 into dumpfile '/tmp/id1.png';
Query OK, 1 row affected (0.001 sec)

MariaDB [liga]> select foto from jugador where id = 2 into dumpfile '/tmp/id2.png';
Query OK, 1 row affected (0.001 sec)

MariaDB [liga]> select foto from jugador where id = 3 into dumpfile '/tmp/id3.png';
Query OK, 1 row affected (0.001 sec)

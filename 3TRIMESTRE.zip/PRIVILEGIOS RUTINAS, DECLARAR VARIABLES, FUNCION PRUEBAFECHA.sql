/*PRIVILEGIOS RUTINAS ALMACENADAS
===============================
Function
========
Privilege	Description
ALTER ROUTINE	Change the characteristics of a stored function using the ALTER FUNCTION statement.
EXECUTE	Use a stored function. You need SELECT privileges for any tables or columns accessed by the function.
GRANT OPTION	Grant function privileges. You can only grant privileges that you have.


Procedure Privileges
====================
Privilege	Description
ALTER ROUTINE	Change the characteristics of a stored procedure using the ALTER PROCEDURE statement.
EXECUTE	Execute a stored procedure using the CALL statement. The privilege to call a procedure may allow you to perform actions you wouldn't otherwise be able to do, such as insert rows into a table.
GRANT OPTION	Grant procedure privileges. You can only grant privileges that you have.

VER PROCEDIMIENTOS
===================
show procedure status\G

DECLARAR VARIABLES EN LA CONSOLA
=================================
*/
MariaDB [liga]> set @p1 = 10; set @p2 = 20; set @p3 = 30;
Query OK, 0 rows affected (0.000 sec)


MariaDB [liga]> call tipoParam(100, @p2, @p3);
+--------------------------------------------------------------+
| CONCAT('p1:', auxiliar1, 'p2:', auxiliar2, 'p3:', auxiliar3) |
+--------------------------------------------------------------+
| NULL                                                         |
+--------------------------------------------------------------+
1 row in set (0.000 sec)

Query OK, 0 rows affected (0.000 sec)

/*FUNCIÓN PRUEBAFECHA (IF)
===========================*/

CREATE FUNCTION liga.pruebaFecha(unaFecha date)
RETURNS varchar(100)
BEGIN
	declare resultado char(10) default 'futuro';
	if unaFecha < curdate() then 
	set resultado = 'pasado';
	elseif	unafecha = curdate () then 
	set resultado = 'presente';
	end if;
	return concat('La fecha está en el: ', resultado);
END


/*FUNCIÓN PRUEBAFECHA (CASE)
=============================*/
CREATE FUNCTION liga.pruebaFechaCase1(unaFecha date)
RETURNS char(50)
BEGIN
declare resultado char(10);
declare resultado2 char(10) default '';
	CASE 
		WHEN unaFecha < curdate() then
			set resultado = 'pasado';
			set resultado2 = 'indefinido';
		WHEN unaFecha = curdate() then
			set resultado = 'presente';
		else
			set resultado = 'futuro';
	END CASE;
	return concat('La fecha está en el: ' + resultado);
END 

/*PROCEDIMIENTO contarWHILE (WHILE)
=================================*/

CREATE PROCEDURE prueba.contarWHILE(in cuenta smallint, out resultado varchar(255))
COMMENT 'Muestra números pares hasta el parámetro'
BEGIN
	declare i smallint default 0;
	WHILE i <= cuenta DO
		if i mod 2 = 0 then 
			set resultado = CONCAT_WS(' ',resultado, i); 
		end if;
		set i = i + 1;
	end while;
END

MariaDB [prueba]> call contarWHILE(10);
+------+
| i    |
+------+
|    0 |
+------+
1 row in set (0.000 sec)

+------+
| i    |
+------+
|    2 |
+------+
1 row in set (0.000 sec)

+------+
| i    |
+------+
|    4 |
+------+
1 row in set (0.001 sec)

+------+
| i    |
+------+
|    6 |
+------+
1 row in set (0.001 sec)

+------+
| i    |
+------+
|    8 |
+------+
1 row in set (0.001 sec)

+------+
| i    |
+------+
|   10 |
+------+
1 row in set (0.001 sec)

/*DEVOLVIENDO TODO EN UNA VARIABLE DE SALIDA QUE CONCATENA LOS PARES
=====================================================================*/

CREATE PROCEDURE prueba.contarWHILE(in cuenta smallint, out resultado varchar(255))
COMMENT 'Muestra números pares hasta el parámetro'
BEGIN
	declare i smallint default 0;
	WHILE i <= cuenta DO
		if i mod 2 = 0 then 
			set resultado = CONCAT_WS(' ',resultado, i); 
		end if;
		set i = i + 1;
	end while;
END

MariaDB [prueba]> call contarWHILE(10, @r);
Query OK, 0 rows affected (0.000 sec)

MariaDB [prueba]> select @r;
+--------------+
| @r           |
+--------------+
| 0 2 4 6 8 10 |
+--------------+
1 row in set (0.000 sec)


/*PROCEDIMIENTO contarREPEAT (REPEAT)
======================================*/
CREATE PROCEDURE prueba.contarREPEAT(in cuenta smallint,  out resultado varchar(255))
COMMENT 'Muestra números pares hasta el parámetro'
BEGIN
	declare i smallint default 0;

	REPEAT
		if i mod 2 = 0 then 
			set resultado = CONCAT_WS(' ',resultado, i); 		
		end if;
		set i = i + 1;
	UNTIL i > cuenta
	
	END REPEAT;
END


/*PROCEDIMIENTO contarFOR (FOR)
================================*/
CREATE PROCEDURE prueba.contarFOR(in cuenta smallint,  out resultado varchar(255))
COMMENT 'Muestra números pares hasta el parámetro'
BEGIN
	declare i smallint default 0;

	FOR i in 0 .. cuenta DO
		if i mod 2 = 0 then 
			set resultado = CONCAT_WS(' ',resultado, i); 
		end if;
	END FOR;
END

MariaDB [prueba]> call contarFOR(10, @r);
Query OK, 0 rows affected (0.000 sec)

MariaDB [prueba]> select @r;
+--------------+
| @r           |
+--------------+
| 0 2 4 6 8 10 |
+--------------+
1 row in set (0.000 sec)


/*PROCEDIMIENTO contarFOR hacia atrás (FOR)
===========================================*/
CREATE PROCEDURE prueba.contarFOR(in cuenta smallint,  out resultado varchar(255))
COMMENT 'Muestra números pares hasta el parámetro'
BEGIN
	declare i smallint default 0;

	FOR i in REVERSE 0 .. cuenta DO
		if i mod 2 = 0 then 
			set resultado = CONCAT_WS(' ',resultado, i); 
		end if;
	END FOR;
END

MariaDB [prueba]> call contarFORREVERSE(20, @r);
Query OK, 0 rows affected (0.001 sec)

MariaDB [prueba]> select @r;
+-----------------------------+
| @r                          |
+-----------------------------+
| 20 18 16 14 12 10 8 6 4 2 0 |
+-----------------------------+
1 row in set (0.000 sec)

MariaDB [prueba]> 

/*FUNCIÓN contarPuntos
=======================*/

CREATE FUNCTION liga.contarPuntos(marcador VARCHAR(7))
RETURNS INT
comment 'Devuelve la suma de los tantos de cada partido'
BEGIN
	
	return SUBSTRING_INDEX(marcador,'-', 1) 
	 + SUBSTRING_INDEX(marcador,'-', 1);
	
END

/*CONTROLANDO EL FORMATO DE ENTRADA
=====================================*/

MariaDB [liga]> select '23-35' rlike '^[0-9]{1,3}-[0-9]{1,3}$';
+-----------------------------------------+
| '23-35' rlike '^[0-9]{1,3}-[0-9]{1,3}$' |
+-----------------------------------------+
|                                       1 |
+-----------------------------------------+
1 row in set (0.000 sec)

CREATE FUNCTION liga.contarPuntos(marcador VARCHAR(7))
RETURNS INT
comment 'Devuelve la suma de los tantos de cada partido'
BEGIN
	if marcador not rlike '^[0-9]{1,3}-[0-9]{1,3}$' then
		return -1;
	else
	return SUBSTRING_INDEX(marcador,'-', 1) 
	 + SUBSTRING_INDEX(marcador,'-', 1);
	end if;
END

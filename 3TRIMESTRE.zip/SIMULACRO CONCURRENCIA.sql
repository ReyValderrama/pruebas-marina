SIMULACRO CONCURRENCIA

RESERVA ONLINE BUTACAS DE CINE

/* RACE CONDITION ESPECIFICA QUE EL HECHO DE QUE UN HILO CORRA MÁS QUE OTRO NO DEBE 
ALTERAR EL RESULTADO REAL QUE DEBERÍA DE SER. NO PORQUE UN HILO ENTRE ANTES 
QUE OTRO DEBE OCASIONAR UN ERROR QUE NO OCURRIRÍA EN CASO CONTRARIO. 
INDEPENDIENTEMENTE DE QUIÉN CORRA MÁS EL RESULTADO, DE UNA MANERA O DE OTRA, 
TIENE QUE SER CORRECTO.*/

mrv@MRV-VirtualBox:~/Escritorio/cine$ mysql -u root -p < cine.sql
Enter password: 

mrv@MRV-VirtualBox:~/Escritorio/cine$ mysql -u root -p cine

-- CREAMOS DOS USUARIOS, ANA Y PEPE, CON TODOS LOS PERMISOS.

MariaDB [cine]> grant all on cine.* to ana identified by '123';
Query OK, 0 rows affected (0.000 sec)

MariaDB [cine]> grant all on cine.* to pepe identified by '123';
Query OK, 0 rows affected (0.000 sec)

-- RELLENAR DE COLOR LA IMAGEN 

-- ABRIMOS LOS DOS USUARIOS, UNO EN CADA CONSOLA, PARA SIMULAR LA CONCURRENCIA

mrv@MRV-VirtualBox:~/Escritorio/cine$ mysql -u ana -p cine

mrv@MRV-VirtualBox:~/Escritorio/cine$ mysql -u pepe -p cine

/*NIVELES DE AISLAMIENTO DE LAS TRANSACCIONES

READ UNCOMMITTED

LECTURAS NO CONFIRMADAS O SUCIAS. CUALQUIER CAMBIO SERÁ VISIBLE POR OTRAS TRANSACCIONES AUNQUE
NO ESTÉN CONFIRMADAS, DE AHÍ QUE SE LLAMEN LECTURAS SUCIAS.

CAMBIAMOS EL NIVEL DE AISLAMIENTO EN AMBOS USUARIOS
====================================================*/

MariaDB [cine]> set session transaction isolation level READ UNCOMMITTED;
Query OK, 0 rows affected (0.000 sec)

MariaDB [cine]> select @@tx_isolation;
+------------------+
| @@tx_isolation   |
+------------------+
| READ-UNCOMMITTED |
+------------------+
1 row in set (0.000 sec)

/*DESDE EL USUARIO ANA SE ABRE TRANSACCIÓN Y SE INTRODUCE UN PAGO */

MariaDB [cine]> begin;
Query OK, 0 rows affected (0.000 sec)

MariaDB [cine]> insert into pago value (null, null, current_user());
Query OK, 1 row affected (0.000 sec)

MariaDB [cine]> select * from pago;
+----+---------------------+---------+
| id | fecha               | usuario |
+----+---------------------+---------+
|  1 | 2022-03-24 13:31:37 | ana@%   |
|  2 | 2022-03-24 13:40:45 | ana@%   |
+----+---------------------+---------+
2 rows in set (0.000 sec)

/*CAMBIAMOS AL USUARIO PEPE PARA VER QUÉ VISIBILIDAD TIENE DE LOS CAMBIOS*/

MariaDB [cine]> begin;
Query OK, 0 rows affected (0.000 sec)

MariaDB [cine]> select * from pago;
+----+---------------------+---------+
| id | fecha               | usuario |
+----+---------------------+---------+
|  1 | 2022-03-24 13:31:37 | ana@%   |
|  2 | 2022-03-24 13:40:45 | ana@%   |
+----+---------------------+---------+
2 rows in set (0.000 sec)


/*READ COMMITTED 
*****************

LOS CAMBIOS SE VEN CUANDO SE HAN CONFIRMADO EN LA TRANSACCIÓN.

CAMBIAMOS EL NIVEL DE AISLAMIENTO EN AMBAS SESIONES (ANA Y PEPE).

MariaDB [cine]> set session transaction isolation level READ COMMITTED;
Query OK, 0 rows affected (0.002 sec)

DESDE EL USUARIO ANA
=====================

VACIAMOS LA TABLA, CREAMOS UN NUEVO PEDIDO Y CONFIRMAMOS TRANSACCIÓN CON EL COMMIT.*/

MariaDB [cine]> truncate pago;
Query OK, 0 rows affected (0.052 sec)

MariaDB [cine]> insert into pago value (null, null, current_user());
Query OK, 1 row affected (0.039 sec)

MariaDB [cine]> select * from pago;
+----+---------------------+---------+
| id | fecha               | usuario |
+----+---------------------+---------+
|  1 | 2022-03-24 13:46:50 | ana@%   |
+----+---------------------+---------+
1 row in set (0.000 sec)

/*CAMBIAMOS EL USUARIO A PEPE, QUIEN PUEDE VERLO PORQUE SE HA HECHO COMMIT
===========================================================================
*/

MariaDB [cine]> select * from pago;
+----+---------------------+---------+
| id | fecha               | usuario |
+----+---------------------+---------+
|  1 | 2022-03-24 13:46:50 | ana@%   |
+----+---------------------+---------+
1 row in set (0.000 s

/*REPETEABLE READ (VALOR POR DEFECTO SI NO SE INDICA)
******************************************************

SE VE LO MISMO QUE SE VEÍA A PARTIR DE LA ENTRADA EN LA TRANSACCIÓN, AUNQUE OTRO USUARIO YA
HAYA CAMBIADO LOS DATOS. 

DESDE EL USUARIO ANA
=====================*/

MariaDB [cine]> begin;
Query OK, 0 rows affected (0.000 sec)

MariaDB [cine]> select 
    -> * from pago;
Empty set (0.000 sec)

MariaDB [cine]> insert into pago value (null, null, current_user());
Query OK, 1 row affected (0.000 sec)

MariaDB [cine]> select * from pago;
+----+---------------------+---------+
| id | fecha               | usuario |
+----+---------------------+---------+
|  1 | 2022-03-24 13:31:37 | ana@%   |
+----+---------------------+---------+
1 row in set (0.000 sec)

/*CAMBIAMOS AL USUARIO PEPE
==========================*/

MariaDB [cine]> select * from pago;
Empty set (0.000 sec)

/*PEPE NO PUEDE VER LOS CAMBIOS. 

SE VUELVE AL USUARIO ANA PARA HACER COMMIT
===========================================*/

MariaDB [cine]> commit;
Query OK, 0 rows affected (0.039 sec)

/*VOLVEMOS AL USUARIO PEPE PARA COMPROBAR LA VISIBILIDAD DE LOS CAMBIOS
=====================================================================

AUN ASÍ SE SIGUEN SIN VER LOS CAMBIOS PORQUE PEPE SIGUE AÚN DENTRO DE LA TRANSACCIÓN.*/

MariaDB [cine]> select * from pago;
Empty set (0.000 sec)

/*CUANDO PEPE HACE COMMIT Y SALE DE LA TRANSACCIÓN YA SÍ SE VEN LOS CAMBIOS*/

MariaDB [cine]> commit;
Query OK, 0 rows affected (0.000 sec)

MariaDB [cine]> select * from pago;
+----+---------------------+---------+
| id | fecha               | usuario |
+----+---------------------+---------+
|  1 | 2022-03-24 13:31:37 | ana@%   |
+----+---------------------+---------+
1 row in set (0.000 sec)


/*SERIALIZABLE 
***************

COMO REPEATABLE READ PERO CADA FILA LEÍDA ESTÁ PROTEGIDA CONTRA ECRITURA DE OTRA TRANSACCIÓN 

PONEMOS AMBOS USUARIOS EN REPEATABLE READ E INICIAMOS TRANSACCIÓN CON AMBOS.*/

MariaDB [cine]> set session transaction isolation level REPEATABLE READ;
Query OK, 0 rows affected (0.000 sec)

/*DESDE EL USUARIO ANA 
=======================*/

MariaDB [cine]> select * from sala where fila = 2 and estado = 'L';
+------+--------+--------+
| fila | butaca | estado |
+------+--------+--------+
|    2 |      1 | L      |
|    2 |      2 | L      |
|    2 |      3 | L      |
|    2 |      4 | L      |
|    2 |      5 | L      |
|    2 |      6 | L      |
|    2 |      7 | L      |
+------+--------+--------+
7 rows in set (0.000 sec)


/*SI HAY UNA INTENCIÓN DE ESCRITURA (UN INTENTO IX) EL SISTEMA NO DEJA QUE HAYA OTRA TRANSACCIÓN 
HASTA QUE ESA TERMINE. PARA PROTEGER UNA OCURRENCIA SE PONE FOR UPDATE Y ASÍ NINGÚN
OTRO USUARIO PUEDE ALTERAR ESA OCURRENCIA HASTA QUE FINALICE LA TRANSACCIÓN.*/

MariaDB [cine]> select * from sala where fila = 2 and butaca = 1 and estado = 'L' for update;
+------+--------+--------+
| fila | butaca | estado |
+------+--------+--------+
|    2 |      1 | L      |
+------+--------+--------+
1 row in set (0.000 sec)

/*CAMBIAMOS A PEPE
==================*/

MariaDB [cine]> select * from sala where fila = 2 and estado = 'L';
+------+--------+--------+
| fila | butaca | estado |
+------+--------+--------+
|    2 |      1 | L      |
|    2 |      2 | L      |
|    2 |      3 | L      |
|    2 |      4 | L      |
|    2 |      5 | L      |
|    2 |      6 | L      |
|    2 |      7 | L      |
+------+--------+--------+
7 rows in set (0.000 sec)

/*PEPE NO PUEDE VER QUE UNA DE ELLAS ESTÁ YA RESERVADA, POR EL NIVEL DE AISLAMIENTO.
SI SE INTENTA HACER LO MISMO, USAR FOR UPDATE PARA "RESERVAR" LA BUTACA, EL SISTEMA
SE BLOQUEA Y NO DEJA FINALIZAR LA TRANSACCIÓN. TIENE UN TIMEOUT PROGRAMADO QUE ESPERA
A QUE EL QUE HIZO PRIMERO EL FOR UPDATE DECIDA QUÉ HACER CON LA TRANSACCIÓN.*/

MariaDB [cine]> select * from sala where fila = 2 and butaca = 1 and estado = 'L' for update;

ERROR 1205 (HY000): Lock wait timeout exceeded; try restarting transaction

/*CAMBIAMOS A USUARIO ANA, MIENTRAS PEPE ESTÁ BLOQUEADO
========================================================*/

MariaDB [cine]> rollback;
Query OK, 0 rows affected (0.000 sec)

/*INMEDIATAMENTE PEPE YA PUEDE BLOQUEAR O RESERVAR LAS BUTACAS Y SALE DEL BLOQUEO DEL SISTEMA*/

MariaDB [cine]> select * from sala where fila = 2 and butaca = 1 and estado = 'L' for update;
+------+--------+--------+
| fila | butaca | estado |
+------+--------+--------+
|    2 |      1 | L      |
+------+--------+--------+
1 row in set (9.179 sec)

-- SIMULAMOS QUE PEPE DECIDE FINALMENTE REALIZAR EL PAGO

MariaDB [cine]> insert into pago value (null, null, current_user());
Query OK, 1 row affected (0.001 sec)

MariaDB [cine]> select * from pago;
+----+---------------------+---------+
| id | fecha               | usuario |
+----+---------------------+---------+
|  1 | 2022-03-24 13:46:50 | ana@%   |
|  2 | 2022-03-24 14:03:11 | pepe@%  |
+----+---------------------+---------+
2 rows in set (0.000 sec)

MariaDB [cine]> update sala set estado = '0' where fila = 2 and butaca = 1;
Query OK, 1 row affected (0.000 sec)
Rows matched: 1  Changed: 1  Warnings: 0

MariaDB [cine]> commit;
Query OK, 0 rows affected (0.038 sec)

/*CAMBIAMOS A ANA PARA COMPROBAR SI PUEDE VER COMO LIBRE LA BUTACA QUE PEPE 
ACABA DE RESERVAR. SPOILER. NO PUEDE.*/

MariaDB [cine]> select * from sala where fila = 2 and estado = 'L';
+------+--------+--------+
| fila | butaca | estado |
+------+--------+--------+
|    2 |      2 | L      |
|    2 |      3 | L      |
|    2 |      4 | L      |
|    2 |      5 | L      |
|    2 |      6 | L      |
|    2 |      7 | L      |
+------+--------+--------+
6 rows in set (0.000 sec)


/*LOCK IN SHARE MODE*/

MariaDB [cine]> select * from pago where id = 6 lock in share mode;
Empty set (0.000 sec)

/*NO SE PUEDE ALTERAR LO QUE ESTÁ EN ESE SELECT HASTA QUE SE ACABE LA TRANSACCIÓN. 
NADIE LA PUEDE MODIFICAR, PERO SÍ LEER. 
DIFERENCIA CON EL UPDATE ES QUE, SI EL OTRO USUARIO TAMBIÉN REALIZA UN SELECT
FOR UPDATE DE LA MISMA OCURRENCIA, NO LE DEJARÍA, NO PUEDE NI LEER, NI EDITAR, CON LOCK IN 
SHARE MODE SE PUEDE LEER, ES DECIR, HACER SELECT, PERO NO UPDATE.
SI EL QUE INICIA LA TRANSACCIÓN Y BLOQUEA CON LOCK IN SHARE MODE, HACE ROLLBACK O 
COMMIT, YA SE PUEDE VOLVER A EDITAR/*


/* SIMULACRO YELMO */

-- PONEMOS AMBOS USUARIOS EN LECTURA SUCIA

set session transaction isolation level READ UNCOMMITTED;

/*CUIDADO CON LOS RANGOS. APARECEN DATOS FANTASMA AL HACER RANGOS, POR EJEMPLO,
SI RESERVAMOS UNA FILA ENTERA PODRÍA COGERSE EL PASILLO COMO UN ASIENTO VÁLIDO
POR ESO ELISEO RECOMIENDA SIEMPRE QUE HAYA QUE PICAR DE ASIENTO EN ASIENTO, DE UNO
EN UNO Y NO DEJAR ELEGIR RANGOS, PORQUE DA MUCHOS PROBLEMAS*/

/*CAMBIAMOS A ANA. COMENZAMOS TRANSACCIÓN Y RESERVAMOS 2 BUTACAS
===============================================================*/

MariaDB [cine]> begin;
Query OK, 0 rows affected (0.000 sec)

MariaDB [cine]> select * from sala where fila = 2 and estado = 'L';
+------+--------+--------+
| fila | butaca | estado |
+------+--------+--------+
|    2 |      2 | L      |
|    2 |      3 | L      |
|    2 |      4 | L      |
|    2 |      5 | L      |
|    2 |      6 | L      |
|    2 |      7 | L      |
+------+--------+--------+
6 rows in set (0.000 sec)

MariaDB [cine]> select * from sala where fila = 2 and butaca in (5,6) for update;
+------+--------+--------+
| fila | butaca | estado |
+------+--------+--------+
|    2 |      5 | L      |
|    2 |      6 | L      |
+------+--------+--------+
2 rows in set (0.000 sec)

MariaDB [cine]> update sala set estado = 'R' where fila = 2 and butaca in (5,6);
Query OK, 2 rows affected (0.000 sec)
Rows matched: 2  Changed: 2  Warnings: 0


/*CAMBMIAMOS A PEPE PARA VER LA VISIBILIDAD
===========================================*/

MariaDB [cine]> select * from sala where fila = 2; 
+------+--------+--------+
| fila | butaca | estado |
+------+--------+--------+
|    2 |      1 | L       |
|    2 |      2 | L      |
|    2 |      3 | L      |
|    2 |      4 | L      |
|    2 |      5 | R      |
|    2 |      6 | R      |
|    2 |      7 | L      |
|    2 |      8 | R      |
+------+--------+--------+
8 rows in set (0.000 sec)

/*COMO ES LECTURA SUCIA, ANTES DE HACER COMMIT, PEPE YA VE QUE HAY DOS ASIENTOS
RESERVADOS

VOLVEMOS AL USUARIO ANA Y SIMULAMOS EL PAGO.
=============================================*/

MariaDB [cine]> insert into pago value (null, null, current_user());
Query OK, 1 row affected (0.000 sec)

MariaDB [cine]> update sala set estado = 'O' where fila = 2 and butaca in (5,6);
Query OK, 2 rows affected (0.038 sec)
Rows matched: 2  Changed: 2  Warnings: 0

MariaDB [cine]> commit; 
Query OK, 0 rows affected (0.039 sec)

/*VOLVEMOS CON EL USUARIO PEPE PARA VER LA VISIBILIDAD TRAS EL COMMIT.
=======================================================================*/

MariaDB [cine]> select * from sala where fila = 2; 
+------+--------+--------+
| fila | butaca | estado |
+------+--------+--------+
|    2 |      1 | L       |
|    2 |      2 | L      |
|    2 |      3 | L      |
|    2 |      4 | L      |
|    2 |      5 | O      |
|    2 |      6 | O      |
|    2 |      7 | L      |
|    2 |      8 | R      |
+------+--------+--------+
8 rows in set (0.000 sec)

*/
Los triggers son códigos que antes del borrado, actualización o inserción 
evitan que ocurra, modican o informan de lo que ha ocurrido. 
Por ejemplo, se puede poner un trigger que cuando un usuario haga una modificación, 
aparezca una ventana de log para indicar quién la ha hecho, a qué hora, etc.

RUTINAS ALMACENADAS
********************

PROCEDIMIENTO
==============

Rutina almacenada que no devuelve nada.

FUNCIÓN
=========

Rutina almacenada que devuelve algún tipo conocido.

SINTAXIS 

Nombre rutina + parámetros (entrada, salida o 1 entrada/salida)

Declaración e inicialización de variables

Procesaiento de datos
Bloques BEGIN/END con instrucciones de control (condicionales y repetitivas)

Fin
Con la Instrucción RETURN para devolver un valoren elcaso de funciones almacenadas


CAMBIAR EL DELIMITADOR
=======================

delimiter #

CREAMOS PROCEDIMIENTO EN UN TEXTO PLANO
========================================

delimiter #

create or replace procedure holaMundo()

begin
	SELECT 'Hola caracola' as Saludo;
end#

delimiter ;


INYECTAMOS CÓDIGO EN LA BBDD PRUEBA
======================================

MariaDB [prueba]> source holamundo.sp
Query OK, 0 rows affected (0.000 sec)

MariaDB [prueba]> show create procedure holamundo\G
*************************** 1. row ***************************
           Procedure: holamundo
            sql_mode: STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION
    Create Procedure: CREATE DEFINER=`root`@`localhost` PROCEDURE `holamundo`()
begin
	SELECT 'Hola caracola' as Saludo;
end
character_set_client: utf8mb4
collation_connection: utf8mb4_general_ci
  Database Collation: utf8mb4_general_ci
1 row in set (0.000 sec)

EJECUTAR PROCEDIMIENTO ALMACENADO (call)
=========================================

MariaDB [prueba]> call holamundo;
+---------------+
| Saludo        |
+---------------+
| Hola caracola |
+---------------+

INSTALAR DBEAVER
=================

https://launchpad.net/~serge-rider/+archive/ubuntu/dbeaver-ce

EN LAS FUNCIONES LOS PARÁMETROS DE ENTRADA SIEMPRE SON IN
==========================================================
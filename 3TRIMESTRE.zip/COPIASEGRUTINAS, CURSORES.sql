
-- COPIA DE SEGURDAD CON RUTINAS ALMACENADAS

mysqldump -uroot -R -p -B concesionario

/*FUNCIÓN OBTENERCAPITAN
==========================*/

MariaDB [liga]> set @eq = 4;
Query OK, 0 rows affected (0.000 sec)

MariaDB [liga]> select * from equipo where id = @eq;
+----+--------------+---------+----------------------------+--------+---------+
| id | nombre       | ciudad  | web_oficial                | puntos | capitan |
+----+--------------+---------+----------------------------+--------+---------+
|  4 | Caja Laboral | Vitoria | http://www.baskonia.com/es |     22 |       5 |
+----+--------------+---------+----------------------------+--------+---------+
1 row in set (0.000 sec)


MariaDB [liga]> select capitan from equipo where id = @eq;
+---------+
| capitan |
+---------+
|       5 |
+---------+

MariaDB [liga]> select * from jugador where id = (select capitan from equipo where id = @eq);
+----+----------+--------------+--------+--------+------------+---------+------+--------+
| id | nombre   | apellido     | altura | puesto | fecha_alta | salario | foto | equipo |
+----+----------+--------------+--------+--------+------------+---------+------+--------+
|  5 | Fernando | San Emeterio |    199 | Alero  | 2008-09-22 |  130000 | NULL |      4 |
+----+----------+--------------+--------+--------+------------+---------+------+--------+
1 row in set (0.011 sec)

MariaDB [liga]> select concat(apellido, ',', nombre, '(',puesto,')') capitan from jugador where id = (select capitan from equipo where id = @eq);
+------------------------------+
| capitan                      |
+------------------------------+
| San Emeterio,Fernando(Alero) |
+------------------------------+
1 row in set (0.000 sec)

/*FUNCIÓN
==========*/

CREATE FUNCTION liga.obtenerCapitan(elEquipo smallint)
RETURNS char(50)
comment 'Devuelve nombre completo del capitán y posición del equipo dado en el parámetro'
BEGIN
	return (SELECT concat(apellido, ',', nombre, '(',puesto,')') capitan from jugador where id = (select capitan from equipo where id = elEquipo));

END

/*RESULTADO
===========*/

MariaDB [liga]> select obtenerCapitan(@eq);
+------------------------------+
| obtenerCapitan(@eq)          |
+------------------------------+
| San Emeterio,Fernando(Alero) |
+------------------------------+
1 row in set (0.001 sec)

/*FUNCIÓN CON VARIABLE LOCAL
=============================*/

CREATE FUNCTION liga.obtenerCapitan(elEquipo smallint)
RETURNS char(50)
comment 'Devuelve nombre completo del capitán y posición del equipo dado en el parámetro'
BEGIN
	declare capi char(50);
	/*return (SELECT concat(apellido, ',', nombre, '(',puesto,')') capitan 
	 from jugador where id = (select capitan from equipo where id = elEquipo));*/
	set capi = (
	SELECT concat(apellido, ',', nombre, '(',puesto,')') capitan 
	 from jugador where id = (select capitan from equipo where id = elEquipo));
	
	 return capi;
END

/*FUNCIÓN CON VARIABLE LOCAL CONTROLANDO NULL
==============================================*/

CREATE FUNCTION liga.obtenerCapitan(elEquipo smallint)
RETURNS char(50)
comment 'Devuelve nombre completo del capitán y posición del equipo dado en el parámetro'
BEGIN
	declare capi char(50);
	/*return (SELECT concat(apellido, ',', nombre, '(',puesto,')') capitan 
	 from jugador where id = (select capitan from equipo where id = elEquipo));*/
	set capi = (
	SELECT concat(apellido, ',', nombre, '(',puesto,')') capitan 
	 from jugador where id = (select capitan from equipo where id = elEquipo));
	
	 return ifnull(capi, '<sin asignar>');
END

MariaDB [liga]> set @eq = 7;
Query OK, 0 rows affected (0.000 sec)

MariaDB [liga]> select obtenerCapitan(@eq);
+---------------------+
| obtenerCapitan(@eq) |
+---------------------+
| <sin asignar>       |
+---------------------+
1 row in set (0.001 sec)

/*CURSOR

ES UN PUNTERO A UN SELECT DE CIERTA DIFICULTAD

CONSISTE EN CREAR EL SELECT NECESARIO, ACTIVAR UN CURSOR SOBRE ESE SELECT, ABRIR LA CONSULTA, RECORRERLA Y CERRARLA.

SINTAXIS: */

DECLARE cursor1 CURSOR FOR
SELECT titulo, contenido, fecha FROM noticias;

/*COMANDOS

OPEN: inicializa el conjunto de resultados asociados con el cursor

FECTH: vuelca lo que devuelve el select en la variable temporal indicada

CLOSE: cierra el recurso

OPEN cursor1;
FETCH cursorl INTO vtitulo, vcontenido, vfecha;
CLOSE cursorl;

MANEJADORES DE EXCEPCIONES
==========================
CONTNUE HANDLER: captura el error y prosigue con la ejecución
EXIT HANDLER: capturo excepción y no continua el procedimiento


FUNCIÓN CURSORCAPITAN
======================
Mediante un cursor, inserta en una nueva columna llamada nomCapitan el nombre y apellido del capitan 
de cada equipo.*/

MariaDB [liga]> alter table equipo add nomCapitan varchar(100) not null;
Query OK, 0 rows affected (0.013 sec)
Records: 0  Duplicates: 0  Warnings: 0

CREATE PROCEDURE liga.cursorCapitan()
COMMENT 'Mediante un cursor asigna nombre completo del capitán de cada equipo'
BEGIN
	declare fin tinyint(1) default 0;							-- Bandera para capturar la excepción
	declare _unCapitan, _unId smallint;							-- Id del capitán 
	-- IMPORTANTE QUE ESTAS DOS ÚLTIMAS DECLARACIONES SEAN LAS ÚLTIMAS 
	declare c1 CURSOR FOR select id, capitan from equipo;		-- Declaración del cursor
	
	-- Esqueleto del manejador de excepciones 
	declare CONTINUE HANDLER for NOT FOUND set fin = 1;			
	begin 
		SET fin = 1;
	end;
	-- Fin del manejador
	-- Esqueleto del cursor para arrancarlo
	OPEN c1;
		-- Mientras fin no sea 1, itera el codigo de su interior. Valdrá 1 cuando salte la excepcion de que no hay mas filas en el select
		WHILE not fin DO
		
			FETCH c1 INTO _unId, _unCapitan;	-- Vuelca el contenido de c1 (2 valores) en las variables indicadas, importante el orden!!
		
			IF _unCapitan is not null THEN
				update equipo set nomCapitan = (select concat(apellido, ', ', nombre) 
												from jugador where id = _unCapitan)
												where id = _unId;
			ELSE
				update equipo set nomCapitan = '<sin asignar>' where id = _unId;
			END IF;
		
		END WHILE;
	CLOSE c1;
	
END

-- MISMA FUNCIÓN SIN CURSOR 

CREATE PROCEDURE liga.sinCursorCapitan()
comment 'lo mismo que la anterior pero sin usar cursor'
BEGIN
	update equipo e set nomCapitan =
	ifnull((select concat(apellido,', ', nombre) 
	from jugador where id = e.capitan), '<sin asignar>');
END

/*USAR FUNCIÓN O PROCEDIMIENTO
Un procedimiento normalmente se usa cuando se va a actualizar información de las tablas, bien porque hace inserciones actualizaciones o borrado de filas, 
hace la llamada al call, recorre y borra, pero no se espera un resultado, como mucho un out resultado que diga si se ha realizado o no.
Sin embargo, cuando lo que se necesita es recuperar información, entonces se usa una función porque se puede anidar y meter dentro de los parámetros de otras funcinoes,
un select es siempre anidable dentro de otro select. Un call no se puede meter dentro de un select./*
